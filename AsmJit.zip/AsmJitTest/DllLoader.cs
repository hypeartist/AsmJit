﻿using System;
using System.Runtime.InteropServices;

namespace AsmJitTest
{

#if X64

	[StructLayoutAttribute(LayoutKind.Sequential)]
	public struct IMAGE_NT_HEADERS
	{

		/// DWORD->unsigned int
		public uint Signature;

		/// IMAGE_FILE_HEADER->_IMAGE_FILE_HEADER
		public IMAGE_FILE_HEADER FileHeader;

		/// IMAGE_OPTIONAL_HEADER64->_IMAGE_OPTIONAL_HEADER64
		public IMAGE_OPTIONAL_HEADER OptionalHeader;
	}

	[StructLayoutAttribute(LayoutKind.Sequential)]
	public struct IMAGE_FILE_HEADER
	{

		/// WORD->unsigned short
		public ushort Machine;

		/// WORD->unsigned short
		public ushort NumberOfSections;

		/// DWORD->unsigned int
		public uint TimeDateStamp;

		/// DWORD->unsigned int
		public uint PointerToSymbolTable;

		/// DWORD->unsigned int
		public uint NumberOfSymbols;

		/// WORD->unsigned short
		public ushort SizeOfOptionalHeader;

		/// WORD->unsigned short
		public ushort Characteristics;
	}

	[StructLayoutAttribute(LayoutKind.Sequential)]
	public unsafe struct IMAGE_OPTIONAL_HEADER
	{

		/// WORD->unsigned short
		public ushort Magic;

		/// BYTE->unsigned char
		public byte MajorLinkerVersion;

		/// BYTE->unsigned char
		public byte MinorLinkerVersion;

		/// DWORD->unsigned int
		public uint SizeOfCode;

		/// DWORD->unsigned int
		public uint SizeOfInitializedData;

		/// DWORD->unsigned int
		public uint SizeOfUninitializedData;

		/// DWORD->unsigned int
		public uint AddressOfEntryPoint;

		/// DWORD->unsigned int
		public uint BaseOfCode;

		/// ULONGLONG->unsigned __int64
		public ulong ImageBase;

		/// DWORD->unsigned int
		public uint SectionAlignment;

		/// DWORD->unsigned int
		public uint FileAlignment;

		/// WORD->unsigned short
		public ushort MajorOperatingSystemVersion;

		/// WORD->unsigned short
		public ushort MinorOperatingSystemVersion;

		/// WORD->unsigned short
		public ushort MajorImageVersion;

		/// WORD->unsigned short
		public ushort MinorImageVersion;

		/// WORD->unsigned short
		public ushort MajorSubsystemVersion;

		/// WORD->unsigned short
		public ushort MinorSubsystemVersion;

		/// DWORD->unsigned int
		public uint Win32VersionValue;

		/// DWORD->unsigned int
		public uint SizeOfImage;

		/// DWORD->unsigned int
		public uint SizeOfHeaders;

		/// DWORD->unsigned int
		public uint CheckSum;

		/// WORD->unsigned short
		public ushort Subsystem;

		/// WORD->unsigned short
		public ushort DllCharacteristics;

		/// ULONGLONG->unsigned __int64
		public ulong SizeOfStackReserve;

		/// ULONGLONG->unsigned __int64
		public ulong SizeOfStackCommit;

		/// ULONGLONG->unsigned __int64
		public ulong SizeOfHeapReserve;

		/// ULONGLONG->unsigned __int64
		public ulong SizeOfHeapCommit;

		/// DWORD->unsigned int
		public uint LoaderFlags;

		/// DWORD->unsigned int
		public uint NumberOfRvaAndSizes;

		/// IMAGE_DATA_DIRECTORY[16]
		public IMAGE_OPTIONAL_HEADER_STRUCT1 DataDirectory;
	}

	[StructLayoutAttribute(LayoutKind.Sequential)]
	public struct IMAGE_DATA_DIRECTORY
	{

		/// DWORD->unsigned int
		public uint VirtualAddress;

		/// DWORD->unsigned int
		public uint Size;
	}

#else
	[StructLayoutAttribute(LayoutKind.Sequential)]
	public struct IMAGE_NT_HEADERS
	{

		/// DWORD->unsigned int
		public uint Signature;

		/// IMAGE_FILE_HEADER->_IMAGE_FILE_HEADER
		public IMAGE_FILE_HEADER FileHeader;

		/// IMAGE_OPTIONAL_HEADER32->_IMAGE_OPTIONAL_HEADER
		public IMAGE_OPTIONAL_HEADER OptionalHeader;
	}

	[StructLayout(LayoutKind.Sequential)]
	public struct IMAGE_FILE_HEADER
	{

		/// WORD->unsigned short
		public ushort Machine;

		/// WORD->unsigned short
		public ushort NumberOfSections;

		/// DWORD->unsigned int
		public uint TimeDateStamp;

		/// DWORD->unsigned int
		public uint PointerToSymbolTable;

		/// DWORD->unsigned int
		public uint NumberOfSymbols;

		/// WORD->unsigned short
		public ushort SizeOfOptionalHeader;

		/// WORD->unsigned short
		public ushort Characteristics;
	}

	[StructLayoutAttribute(LayoutKind.Sequential)]
	public struct IMAGE_OPTIONAL_HEADER
	{

		/// WORD->unsigned short
		public ushort Magic;

		/// BYTE->unsigned char
		public byte MajorLinkerVersion;

		/// BYTE->unsigned char
		public byte MinorLinkerVersion;

		/// DWORD->unsigned int
		public uint SizeOfCode;

		/// DWORD->unsigned int
		public uint SizeOfInitializedData;

		/// DWORD->unsigned int
		public uint SizeOfUninitializedData;

		/// DWORD->unsigned int
		public uint AddressOfEntryPoint;

		/// DWORD->unsigned int
		public uint BaseOfCode;

		/// DWORD->unsigned int
		public uint BaseOfData;

		/// DWORD->unsigned int
		public uint ImageBase;

		/// DWORD->unsigned int
		public uint SectionAlignment;

		/// DWORD->unsigned int
		public uint FileAlignment;

		/// WORD->unsigned short
		public ushort MajorOperatingSystemVersion;

		/// WORD->unsigned short
		public ushort MinorOperatingSystemVersion;

		/// WORD->unsigned short
		public ushort MajorImageVersion;

		/// WORD->unsigned short
		public ushort MinorImageVersion;

		/// WORD->unsigned short
		public ushort MajorSubsystemVersion;

		/// WORD->unsigned short
		public ushort MinorSubsystemVersion;

		/// DWORD->unsigned int
		public uint Win32VersionValue;

		/// DWORD->unsigned int
		public uint SizeOfImage;

		/// DWORD->unsigned int
		public uint SizeOfHeaders;

		/// DWORD->unsigned int
		public uint CheckSum;

		/// WORD->unsigned short
		public ushort Subsystem;

		/// WORD->unsigned short
		public ushort DllCharacteristics;

		/// DWORD->unsigned int
		public uint SizeOfStackReserve;

		/// DWORD->unsigned int
		public uint SizeOfStackCommit;

		/// DWORD->unsigned int
		public uint SizeOfHeapReserve;

		/// DWORD->unsigned int
		public uint SizeOfHeapCommit;

		/// DWORD->unsigned int
		public uint LoaderFlags;

		/// DWORD->unsigned int
		public uint NumberOfRvaAndSizes;

		/// IMAGE_DATA_DIRECTORY[16]
		public IMAGE_OPTIONAL_HEADER_STRUCT1 DataDirectory;
	}



	[StructLayout(LayoutKind.Sequential)]
	public struct IMAGE_DATA_DIRECTORY
	{

		/// DWORD->unsigned int
		public uint VirtualAddress;

		/// DWORD->unsigned int
		public uint Size;
	}
#endif

	[StructLayout(LayoutKind.Explicit)]
	public struct IMAGE_OPTIONAL_HEADER_STRUCT1
	{
		[FieldOffset(0 * 8)]
		public IMAGE_DATA_DIRECTORY D0;
		[FieldOffset(1 * 8)]
		public IMAGE_DATA_DIRECTORY D1;
		[FieldOffset(2 * 8)]
		public IMAGE_DATA_DIRECTORY D2;
		[FieldOffset(3 * 8)]
		public IMAGE_DATA_DIRECTORY D3;
		[FieldOffset(4 * 8)]
		public IMAGE_DATA_DIRECTORY D4;
		[FieldOffset(5 * 8)]
		public IMAGE_DATA_DIRECTORY D5;
		[FieldOffset(6 * 8)]
		public IMAGE_DATA_DIRECTORY D6;
		[FieldOffset(7 * 8)]
		public IMAGE_DATA_DIRECTORY D7;
		[FieldOffset(8 * 8)]
		public IMAGE_DATA_DIRECTORY D8;
		[FieldOffset(9 * 8)]
		public IMAGE_DATA_DIRECTORY D9;
		[FieldOffset(10 * 8)]
		public IMAGE_DATA_DIRECTORY D10;
		[FieldOffset(11 * 8)]
		public IMAGE_DATA_DIRECTORY D11;
		[FieldOffset(12 * 8)]
		public IMAGE_DATA_DIRECTORY D12;
		[FieldOffset(13 * 8)]
		public IMAGE_DATA_DIRECTORY D13;
		[FieldOffset(14 * 8)]
		public IMAGE_DATA_DIRECTORY D14;
		[FieldOffset(15 * 8)]
		public IMAGE_DATA_DIRECTORY D15;
	}

	[StructLayout(LayoutKind.Sequential)]
	public unsafe struct IMAGE_DOS_HEADER
	{

		/// WORD->unsigned short
		public ushort e_magic;

		/// WORD->unsigned short
		public ushort e_cblp;

		/// WORD->unsigned short
		public ushort e_cp;

		/// WORD->unsigned short
		public ushort e_crlc;

		/// WORD->unsigned short
		public ushort e_cparhdr;

		/// WORD->unsigned short
		public ushort e_minalloc;

		/// WORD->unsigned short
		public ushort e_maxalloc;

		/// WORD->unsigned short
		public ushort e_ss;

		/// WORD->unsigned short
		public ushort e_sp;

		/// WORD->unsigned short
		public ushort e_csum;

		/// WORD->unsigned short
		public ushort e_ip;

		/// WORD->unsigned short
		public ushort e_cs;

		/// WORD->unsigned short
		public ushort e_lfarlc;

		/// WORD->unsigned short
		public ushort e_ovno;

		/// WORD[4]
		public fixed ushort e_res[4];

		/// WORD->unsigned short
		public ushort e_oemid;

		/// WORD->unsigned short
		public ushort e_oeminfo;

		/// WORD[10]
		public fixed ushort e_res2[10];

		/// LONG->int
		public int e_lfanew;
	}


	[StructLayoutAttribute(LayoutKind.Sequential)]
	public struct SYSTEM_INFO
	{

		/// Anonymous_459bdf75_2992_4fef_9fb5_389952f59d12
		public SYSTEM_INFO_UNION1 Union1;

		/// DWORD->unsigned int
		public uint dwPageSize;

		/// LPVOID->void*
		public IntPtr lpMinimumApplicationAddress;

		/// LPVOID->void*
		public IntPtr lpMaximumApplicationAddress;

		/// DWORD_PTR->ULONG_PTR->unsigned int
		public uint dwActiveProcessorMask;

		/// DWORD->unsigned int
		public uint dwNumberOfProcessors;

		/// DWORD->unsigned int
		public uint dwProcessorType;

		/// DWORD->unsigned int
		public uint dwAllocationGranularity;

		/// WORD->unsigned short
		public ushort wProcessorLevel;

		/// WORD->unsigned short
		public ushort wProcessorRevision;
	}

	[StructLayout(LayoutKind.Explicit)]
	public struct SYSTEM_INFO_UNION1
	{

		/// DWORD->unsigned int
		[FieldOffset(0)]
		public uint dwOemId;

		/// Anonymous_a30d5f78_3b46_471a_9d25_915a0fe3987d
		[FieldOffset(0)]
		public SYSTEM_INFO_UNION1_STRUCT1 Struct1;
	}

	[StructLayout(LayoutKind.Sequential)]
	public struct SYSTEM_INFO_UNION1_STRUCT1
	{

		/// WORD->unsigned short
		public ushort wProcessorArchitecture;

		/// WORD->unsigned short
		public ushort wReserved;
	}


	[StructLayout(LayoutKind.Sequential)]
	public unsafe struct IMAGE_SECTION_HEADER
	{

		/// BYTE[8]
		public fixed byte Name[8];

		/// Anonymous_c9386319_923c_4f10_ad71_12ce6f4c7b4e
		public IMAGE_SECTION_HEADER_UNION1 Misc;

		/// DWORD->unsigned int
		public uint VirtualAddress;

		/// DWORD->unsigned int
		public uint SizeOfRawData;

		/// DWORD->unsigned int
		public uint PointerToRawData;

		/// DWORD->unsigned int
		public uint PointerToRelocations;

		/// DWORD->unsigned int
		public uint PointerToLinenumbers;

		/// WORD->unsigned short
		public ushort NumberOfRelocations;

		/// WORD->unsigned short
		public ushort NumberOfLinenumbers;

		/// DWORD->unsigned int
		public uint Characteristics;
	}

	[StructLayout(LayoutKind.Explicit)]
	public struct IMAGE_SECTION_HEADER_UNION1
	{

		/// DWORD->unsigned int
		[FieldOffset(0)]
		public uint PhysicalAddress;

		/// DWORD->unsigned int
		[FieldOffset(0)]
		public uint VirtualSize;
	}

	[StructLayout(LayoutKind.Sequential)]
	public struct IMAGE_BASE_RELOCATION
	{

		/// DWORD->unsigned int
		public uint VirtualAddress;

		/// DWORD->unsigned int
		public uint SizeOfBlock;
	}

	[StructLayout(LayoutKind.Sequential)]
	public struct IMAGE_IMPORT_DESCRIPTOR
	{
		/// Anonymous_7dadb22a_8bbe_4747_9d2a_2d35c978fd6b
		public IMAGE_IMPORT_DESCRIPTOR_UNION1 Union1;

		/// DWORD->unsigned int
		public uint TimeDateStamp;

		/// DWORD->unsigned int
		public uint ForwarderChain;

		/// DWORD->unsigned int
		public uint Name;

		/// DWORD->unsigned int
		public uint FirstThunk;
	}

	[StructLayout(LayoutKind.Explicit)]
	public struct IMAGE_IMPORT_DESCRIPTOR_UNION1
	{

		/// DWORD->unsigned int
		[FieldOffset(0)]
		public uint Characteristics;

		/// DWORD->unsigned int
		[FieldOffset(0)]
		public uint OriginalFirstThunk;
	}

	public unsafe struct IMAGE_IMPORT_BY_NAME
	{

		/// WORD->unsigned short
		public ushort Hint;

		/// BYTE[1]
		public fixed byte Name[1];
	}

#if X64

	[StructLayout(LayoutKind.Sequential)]
	public struct IMAGE_TLS_DIRECTORY
	{

		/// ULONGLONG->unsigned __int64
		public ulong StartAddressOfRawData;

		/// ULONGLONG->unsigned __int64
		public ulong EndAddressOfRawData;

		/// ULONGLONG->unsigned __int64
		public ulong AddressOfIndex;

		/// ULONGLONG->unsigned __int64
		public ulong AddressOfCallBacks;

		/// DWORD->unsigned int
		public uint SizeOfZeroFill;

		/// DWORD->unsigned int
		public uint Characteristics;
	}
#else
	[StructLayout(LayoutKind.Sequential)]
	public struct IMAGE_TLS_DIRECTORY
	{

		/// DWORD->unsigned int
		public uint StartAddressOfRawData;

		/// DWORD->unsigned int
		public uint EndAddressOfRawData;

		/// DWORD->unsigned int
		public uint AddressOfIndex;

		/// DWORD->unsigned int
		public uint AddressOfCallBacks;

		/// DWORD->unsigned int
		public uint SizeOfZeroFill;

		/// DWORD->unsigned int
		public uint Characteristics;
	}
#endif

	[StructLayout(LayoutKind.Sequential)]
	public struct IMAGE_EXPORT_DIRECTORY
	{

		/// DWORD->unsigned int
		public uint Characteristics;

		/// DWORD->unsigned int
		public uint TimeDateStamp;

		/// WORD->unsigned short
		public ushort MajorVersion;

		/// WORD->unsigned short
		public ushort MinorVersion;

		/// DWORD->unsigned int
		public uint Name;

		/// DWORD->unsigned int
		public uint Base;

		/// DWORD->unsigned int
		public uint NumberOfFunctions;

		/// DWORD->unsigned int
		public uint NumberOfNames;

		/// DWORD->unsigned int
		public uint AddressOfFunctions;

		/// DWORD->unsigned int
		public uint AddressOfNames;

		/// DWORD->unsigned int
		public uint AddressOfNameOrdinals;
	}

	public unsafe struct MEMORYMODULE
	{
		public IMAGE_NT_HEADERS* headers;
		public byte* codeBase;
		public void** modules;
		public int numModules;
		public bool initialized;
		public bool isDLL;
		public bool isRelocated;
		public void* loadLibrary;
		public void* getProcAddress;
		public void* freeLibrary;
		public void* userdata;
		public void* exeEntry;
		public uint pageSize;
	}

	public unsafe struct SECTIONFINALIZEDATA
	{
		public void* address;
		public void* alignedAddress;
		public uint size;
		public uint characteristics;
		public bool last;
	}

	public class DllLoader
	{
		public const int IMAGE_DOS_SIGNATURE = 0x5A4D;
		public const int IMAGE_NT_SIGNATURE = 0x00004550;
		public const int IMAGE_FILE_MACHINE_AMD64 = 0x8664;
		public const int IMAGE_FILE_MACHINE_I386 = 0x014c;
		public const int IMAGE_FILE_DLL = 0x2000;

		public const int MEM_RESERVE = 0x2000;
		public const int MEM_COMMIT = 0x1000;
		public const int MEM_RELEASE = 0x8000;
		public const int MEM_DECOMMIT = 0x4000;

		public const int IMAGE_DIRECTORY_ENTRY_IMPORT = 1;
		public const int IMAGE_DIRECTORY_ENTRY_BASERELOC = 5;
		public const int IMAGE_DIRECTORY_ENTRY_TLS = 9;
		public const int IMAGE_DIRECTORY_ENTRY_EXPORT = 0;
		public const int IMAGE_SIZEOF_BASE_RELOCATION = 8;
		public const int IMAGE_REL_BASED_ABSOLUTE = 0;
		public const int IMAGE_REL_BASED_HIGHLOW = 3;
		public const int IMAGE_REL_BASED_DIR64 = 10;

		public const int IMAGE_SCN_CNT_INITIALIZED_DATA = 0x00000040;
		public const int IMAGE_SCN_CNT_UNINITIALIZED_DATA = 0x00000080;
		public const int IMAGE_SCN_MEM_DISCARDABLE = 0x02000000;
		public const int IMAGE_SCN_MEM_EXECUTE = 0x20000000;
		public const int IMAGE_SCN_MEM_READ = 0x40000000;
		public const uint IMAGE_SCN_MEM_WRITE = 0x80000000;
		public const int IMAGE_SCN_MEM_NOT_CACHED = 0x04000000;

		public const uint PAGE_READWRITE = 0x04;
		public const uint PAGE_NOCACHE = 0x200;
		public const uint PAGE_NOACCESS = 0x01;
		public const uint PAGE_WRITECOPY = 0x08;
		public const uint PAGE_READONLY = 0x02;
		public const uint PAGE_EXECUTE = 0x10;
		public const uint PAGE_EXECUTE_WRITECOPY = 0x80;
		public const uint PAGE_EXECUTE_READ = 0x20;
		public const uint PAGE_EXECUTE_READWRITE = 0x40;

		public const int DLL_PROCESS_ATTACH = 1;
		public const int DLL_PROCESS_DETACH = 0;

#if X64
		public const ulong IMAGE_ORDINAL_FLAG = 0x8000000000000000;
#else
		public const uint IMAGE_ORDINAL_FLAG = 0x80000000;
#endif

		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		public delegate void PIMAGE_TLS_CALLBACK(IntPtr DllHandle, uint Reason, IntPtr Reserved);

		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		public unsafe delegate bool DllEntryProc(void* DllHandle, uint Reason, IntPtr Reserved);

		[UnmanagedFunctionPointer(CallingConvention.StdCall)]
		public delegate void ExeEntryProc();

		[DllImport("kernel32.dll", EntryPoint = "GetNativeSystemInfo")]
		public static extern void GetNativeSystemInfo([Out] out SYSTEM_INFO lpSystemInfo);

		[DllImport("kernel32.dll", EntryPoint = "VirtualAlloc")]
		public static extern IntPtr VirtualAlloc([In] IntPtr lpAddress, uint dwSize, uint flAllocationType, uint flProtect);


		[DllImport("kernel32.dll", EntryPoint = "VirtualFree")]
		public static extern bool VirtualFree([In] IntPtr lpAddress, uint dwSize, uint dwFreeType);


		[DllImport("kernel32.dll", EntryPoint = "VirtualProtect")]
		[return: MarshalAs(UnmanagedType.Bool)]
		public static extern bool VirtualProtect([In] IntPtr lpAddress, uint dwSize, uint flNewProtect, [Out] out uint lpflOldProtect);

		[DllImport("kernel32.dll", EntryPoint = "IsBadReadPtr")]
		[return: MarshalAs(UnmanagedType.Bool)]
		public static extern bool IsBadReadPtr(IntPtr lp, uint ucb);

		/// Return Type: HMODULE->HINSTANCE->HINSTANCE__*
		///lpLibFileName: LPCSTR->CHAR*
		[DllImport("kernel32.dll", EntryPoint = "LoadLibraryA")]
		public static extern unsafe IntPtr LoadLibrary([In] void* lpLibFileName/*[MarshalAs(UnmanagedType.LPStr)] string lpLibFileName*/);

		[DllImport("kernel32.dll", EntryPoint = "FreeLibrary")]
		[return: MarshalAs(UnmanagedType.Bool)]
		public static extern bool FreeLibrary([In] IntPtr hLibModule);


		[DllImport("kernel32.dll", EntryPoint = "GetProcAddress")]
		public static extern unsafe IntPtr GetProcAddress([In] IntPtr hModule, [In] void* lpProcName);

		[DllImport("ntdll.dll", EntryPoint = "memset", CallingConvention = CallingConvention.Cdecl)]
		public static extern IntPtr memset(IntPtr dst, int val, uint size);

		[DllImport("msvcrt.dll", EntryPoint = "free", CallingConvention = CallingConvention.Cdecl)]
		public static extern void free(IntPtr memory);

		[DllImport("msvcrt.dll", EntryPoint = "realloc", CallingConvention = CallingConvention.Cdecl)]
		public static extern IntPtr realloc(IntPtr memory, uint newSize);

		public unsafe IntPtr MemoryLoadLibraryEx(byte[] bdata, int size)
		{
			var data = (void*)Marshal.AllocHGlobal(size);
			fixed (byte* pb = bdata)
			{
				Buffer.MemoryCopy(pb, data, size, size);
			}

			SYSTEM_INFO sysInfo;
			int i;
			uint lastSectionEnd = 0;

			if (!CheckSize(size, sizeof(IMAGE_DOS_HEADER)))
			{
				return IntPtr.Zero;
			}

			var dosHeader = (IMAGE_DOS_HEADER*) data;
			if (dosHeader->e_magic != IMAGE_DOS_SIGNATURE)
			{
				return IntPtr.Zero;
			}

			if (!CheckSize(size, dosHeader->e_lfanew + sizeof(IMAGE_NT_HEADERS)))
			{
				return IntPtr.Zero;
			}

			var oldHeader = (IMAGE_NT_HEADERS*)((byte*)data + dosHeader->e_lfanew);
			if (oldHeader->Signature != IMAGE_NT_SIGNATURE)
			{
				return IntPtr.Zero;
			}

#if X64
			if (oldHeader->FileHeader.Machine != IMAGE_FILE_MACHINE_AMD64)
#else
			if (oldHeader->FileHeader.Machine != IMAGE_FILE_MACHINE_I386)
#endif
			{
				return IntPtr.Zero;
			}

			if ((oldHeader->OptionalHeader.SectionAlignment & 1) != 0)
			{
				// Only support section alignments that are a multiple of 2
				return IntPtr.Zero;
			}

			var section = IMAGE_FIRST_SECTION(oldHeader);
			var optionalSectionSize = oldHeader->OptionalHeader.SectionAlignment;
			for (i = 0; i < oldHeader->FileHeader.NumberOfSections; i++, section++)
			{
				uint endOfSection;
				if (section->SizeOfRawData == 0)
				{
					// Section without data in the DLL
					endOfSection = section->VirtualAddress + optionalSectionSize;
				}
				else
				{
					endOfSection = section->VirtualAddress + section->SizeOfRawData;
				}

				if (endOfSection > lastSectionEnd)
				{
					lastSectionEnd = endOfSection;
				}
			}

			GetNativeSystemInfo(out sysInfo);
			var alignedImageSize = ALIGN_VALUE_UP(oldHeader->OptionalHeader.SizeOfImage, sysInfo.dwPageSize);
			if (alignedImageSize != ALIGN_VALUE_UP(lastSectionEnd, sysInfo.dwPageSize))
			{
				return IntPtr.Zero;
			}

			// reserve memory for image of library
			// XXX: is it correct to commit the complete memory region at once?
			//      calling DllEntry raises an exception if we don't...
			var code = (byte*) VirtualAlloc((IntPtr) oldHeader->OptionalHeader.ImageBase, alignedImageSize, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);
			if (code == (void*) 0)
			{
				// try to allocate memory at arbitrary position
				code = (byte*) VirtualAlloc(IntPtr.Zero, alignedImageSize, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);
				if (code == (void*) 0)
				{
					return IntPtr.Zero;
				}
			}

			var result = (MEMORYMODULE*) Marshal.AllocHGlobal(sizeof(MEMORYMODULE));
			memset((IntPtr) result, 0, (uint) sizeof(MEMORYMODULE));
			if (result == (void*) 0)
			{
				VirtualFree((IntPtr) code, 0, MEM_RELEASE);
				return IntPtr.Zero;
			}

			result->codeBase = code;
			result->isDLL = (oldHeader->FileHeader.Characteristics & IMAGE_FILE_DLL) != 0;
			result->loadLibrary = (void*) 0;
			result->getProcAddress = (void*) 0;
			result->freeLibrary = (void*) 0;
			result->userdata = (void*) 0;
			result->pageSize = sysInfo.dwPageSize;

			if (!CheckSize(size, (int) oldHeader->OptionalHeader.SizeOfHeaders))
			{
				MemoryFreeLibrary(result);
				return IntPtr.Zero;
			}

			// commit memory for headers
			var headers = (byte*) VirtualAlloc((IntPtr) code, oldHeader->OptionalHeader.SizeOfHeaders, MEM_COMMIT, PAGE_READWRITE);

			// copy PE header to code
			Buffer.MemoryCopy(dosHeader, headers, oldHeader->OptionalHeader.SizeOfHeaders, oldHeader->OptionalHeader.SizeOfHeaders);
			result->headers = (IMAGE_NT_HEADERS*) &headers[dosHeader->e_lfanew];

			// update position
#if X64
			result->headers->OptionalHeader.ImageBase = (ulong) code;
#else
			result->headers->OptionalHeader.ImageBase = (uint)code;
#endif
			

			// copy sections from DLL file block to new memory location
			if (!CopySections((byte*) data, size, oldHeader, result))
			{
				MemoryFreeLibrary(result);
				return IntPtr.Zero;
			}

			// adjust base address of imported data
			var locationDelta = result->headers->OptionalHeader.ImageBase - oldHeader->OptionalHeader.ImageBase;
			if (locationDelta != 0)
			{
				result->isRelocated = PerformBaseRelocation(result, locationDelta);
			}
			else
			{
				result->isRelocated = true;
			}

			// load required dlls and adjust function table of imports
			if (!BuildImportTable(result))
			{
				MemoryFreeLibrary(result);
				return IntPtr.Zero;
			}

			// mark memory pages depending on section headers and release
			// sections that are marked as "discardable"
			if (!FinalizeSections(result))
			{
				MemoryFreeLibrary(result);
				return IntPtr.Zero;
			}

			// TLS callbacks are executed BEFORE the main loading
			if (!ExecuteTLS(result))
			{
				MemoryFreeLibrary(result);
				return IntPtr.Zero;
			}

			// get entry point of loaded library
			if (result->headers->OptionalHeader.AddressOfEntryPoint != 0)
			{
				if (result->isDLL)
				{
					var dllEntry = Marshal.GetDelegateForFunctionPointer<DllEntryProc>((IntPtr) (code + result->headers->OptionalHeader.AddressOfEntryPoint));//(DllEntryProc)(LPVOID)(code + result->headers->OptionalHeader.AddressOfEntryPoint);
					// notify library about attaching to process
					bool successfull = false;
					successfull = dllEntry(code, DLL_PROCESS_ATTACH, IntPtr.Zero);
					result->initialized = true;
					if (!successfull)
					{
						MemoryFreeLibrary(result);
						return IntPtr.Zero;
					}
				}
				else
				{
					result->exeEntry = code + result->headers->OptionalHeader.AddressOfEntryPoint;
				}
			}
			else
			{
				result->exeEntry = (void*) 0;
			}

			return (IntPtr) result;
		}

		public unsafe IntPtr MemoryGetProcAddress(IntPtr mod, string name)
		{
			var module = (MEMORYMODULE*) mod;
			var codeBase = module->codeBase;
			var idx = 0;
			var directory = GET_HEADER_DICTIONARY(module, IMAGE_DIRECTORY_ENTRY_EXPORT);
			if (directory->Size == 0)
			{
				// no export table found
				return IntPtr.Zero;
			}

			var exports = (IMAGE_EXPORT_DIRECTORY*) (codeBase + directory->VirtualAddress);
			if (exports->NumberOfNames == 0 || exports->NumberOfFunctions == 0)
			{
				// DLL doesn't export anything
				return IntPtr.Zero;
			}

//    if (HIWORD(name) == 0) {
//        // load function by ordinal value
//        if (LOWORD(name) < exports->Base) {
//            SetLastError(ERROR_PROC_NOT_FOUND);
//            return NULL;
//        }
//
//        idx = LOWORD(name) - exports->Base;
//    } else {
//
//    }
			// search function name in list of exported names
			int i;
			var nameRef = (uint*) (codeBase + exports->AddressOfNames);
			var ordinal = (ushort*) (codeBase + exports->AddressOfNameOrdinals);
			var found = false;
			for (i = 0; i < exports->NumberOfNames; i++, nameRef++, ordinal++)
			{
				var str = Marshal.PtrToStringAnsi((IntPtr) (codeBase + *nameRef));
				if (str != name) continue;
				idx = *ordinal;
				found = true;
				break;
			}

			if (!found)
			{
				// exported symbol not found
				return IntPtr.Zero;
			}

			if (idx > exports->NumberOfFunctions)
			{
				// name <-> ordinal number don't match
				return IntPtr.Zero;
			}

			// AddressOfFunctions contains the RVAs to the "real" functions
			return (IntPtr) (codeBase + *(uint*) (codeBase + exports->AddressOfFunctions + idx*4));
		}

		public static int LOWORD(IntPtr p)
		{
			return unchecked((short)(long)p);
		}

		public static int HIWORD(IntPtr p)
		{
			return unchecked((short)((long)p >> 16));
		}

		private unsafe void MemoryFreeLibrary(MEMORYMODULE* module)
		{
			if (module == (void*) 0)
			{
				return;
			}
			if (module->initialized)
			{
				// notify library about detaching from process
				var dllEntry = Marshal.GetDelegateForFunctionPointer<DllEntryProc>((IntPtr)(module->codeBase + module->headers->OptionalHeader.AddressOfEntryPoint));
				dllEntry(module->codeBase, DLL_PROCESS_DETACH, IntPtr.Zero);
			}

			if (module->modules != (void*) 0)
			{
				// free previously opened libraries
				int i;
				for (i = 0; i < module->numModules; i++)
				{
					if (module->modules[i] != (void*) 0)
					{
						FreeLibrary((IntPtr) module->modules[i]);
					}
				}

				free((IntPtr) module->modules);
			}

			if (module->codeBase != (void*) 0)
			{
				// release memory of library
				VirtualFree((IntPtr) module->codeBase, 0, MEM_RELEASE);
			}

			Marshal.FreeHGlobal((IntPtr) module);
		}

		private unsafe bool CopySections(byte* data, int size, IMAGE_NT_HEADERS* oldHeaders, MEMORYMODULE* module)
		{
			uint i;
			var codeBase = module->codeBase;
			var section = IMAGE_FIRST_SECTION(module->headers);
			for (i = 0; i < module->headers->FileHeader.NumberOfSections; i++, section++)
			{
				byte* dest;
				if (section->SizeOfRawData == 0)
				{
					// section doesn't contain data in the dll itself, but may define
					// uninitialized data
					var sectionSize = oldHeaders->OptionalHeader.SectionAlignment;
					if (sectionSize > 0)
					{
						dest = (byte*) VirtualAlloc((IntPtr) (codeBase + section->VirtualAddress), sectionSize, MEM_COMMIT, PAGE_READWRITE);
						if (dest == (void*) 0)
						{
							return false;
						}

						// Always use position from file to support alignments smaller
						// than page size.
						dest = codeBase + section->VirtualAddress;
						section->Misc.PhysicalAddress = (uint) (ulong) dest;
						memset((IntPtr) dest, 0, sectionSize);
					}

					// section is empty
					continue;
				}

				if (!CheckSize(size, (int) (section->PointerToRawData + section->SizeOfRawData)))
				{
					return false;
				}

				// commit memory block and copy data from dll
				dest = (byte*) VirtualAlloc((IntPtr) (codeBase + section->VirtualAddress), section->SizeOfRawData, MEM_COMMIT, PAGE_READWRITE);
				if (dest == (void*) 0)
				{
					return false;
				}

				// Always use position from file to support alignments smaller
				// than page size.
				dest = codeBase + section->VirtualAddress;
				Buffer.MemoryCopy(data + section->PointerToRawData, dest, section->SizeOfRawData, section->SizeOfRawData);
				section->Misc.PhysicalAddress = (uint) (ulong) dest;
			}

			return true;
		}

		private static unsafe bool PerformBaseRelocation(MEMORYMODULE* module, ulong delta)
		{
			var codeBase = module->codeBase;

			var directory = GET_HEADER_DICTIONARY(module, IMAGE_DIRECTORY_ENTRY_BASERELOC);
			if (directory->Size == 0)
			{
				return delta == 0;
			}

			var relocation = (IMAGE_BASE_RELOCATION*) (codeBase + directory->VirtualAddress);
			for (; relocation->VirtualAddress > 0;)
			{
				uint i;
				var dest = codeBase + relocation->VirtualAddress;
				var relInfo = (ushort*) ((byte*) relocation + IMAGE_SIZEOF_BASE_RELOCATION);
				for (i = 0; i < (relocation->SizeOfBlock - IMAGE_SIZEOF_BASE_RELOCATION)/2; i++, relInfo++)
				{
					// the upper 4 bits define the type of relocation
					var type = *relInfo >> 12;
					// the lower 12 bits define the offset
					var offset = *relInfo & 0xfff;

					switch (type)
					{
						case IMAGE_REL_BASED_ABSOLUTE:
							// skip relocation
							break;

						case IMAGE_REL_BASED_HIGHLOW:
							// change complete 32 bit address
							var patchAddrHl = (uint*) (dest + offset);
							*patchAddrHl += (uint) delta;
							break;

#if X64
						case IMAGE_REL_BASED_DIR64:
							var patchAddr64 = (ulong*) (dest + offset);
							*patchAddr64 += (ulong) delta;
							break;
#endif

						default:
							//printf("Unknown relocation: %d\n", type);
							break;
					}
				}
				// advance to next relocation block
				relocation = (IMAGE_BASE_RELOCATION*) ((byte*) relocation + relocation->SizeOfBlock);
			}
			return true;
		}

		private unsafe bool BuildImportTable(MEMORYMODULE* module)
		{
			var codeBase = module->codeBase;
			IMAGE_IMPORT_DESCRIPTOR* importDesc;
			var result = true;

			var directory = GET_HEADER_DICTIONARY(module, IMAGE_DIRECTORY_ENTRY_IMPORT);
			if (directory->Size == 0)
			{
				return true;
			}

			importDesc = (IMAGE_IMPORT_DESCRIPTOR*)(codeBase + directory->VirtualAddress);
			for (; !IsBadReadPtr((IntPtr) importDesc, (uint) sizeof(IMAGE_IMPORT_DESCRIPTOR)) && importDesc->Name != 0; importDesc++)
			{
				uint* thunkRef;
				void** funcRef;
				void** tmp;
				var handle = LoadLibrary(codeBase + importDesc->Name);//module->loadLibrary((LPCSTR)(codeBase + importDesc->Name), module->userdata);
				if (handle == (IntPtr) 0)
				{
					result = false;
					break;
				}

				tmp = (void**)realloc((IntPtr) module->modules, (uint) ((module->numModules + 1) * sizeof(void*)));
				if (tmp == (void*) 0)
				{
//					module->freeLibrary(handle, module->userdata);
					FreeLibrary(handle);
					result = false;
					break;
				}
				module->modules = (void**) tmp;

				module->modules[module->numModules++] = (void*) handle;
				if (importDesc->Union1.OriginalFirstThunk != 0)
				{
					thunkRef = (uint*)(codeBase + importDesc->Union1.OriginalFirstThunk);
					funcRef = (void**) (codeBase + importDesc->FirstThunk);
				}
				else
				{
					// no hint table
					thunkRef = (uint*)(codeBase + importDesc->FirstThunk);
					funcRef = (void**) (codeBase + importDesc->FirstThunk);
				}
				for (; *thunkRef != 0; thunkRef++, funcRef++)
				{
					if (IMAGE_SNAP_BY_ORDINAL(*thunkRef))
					{
						*funcRef = (void*) GetProcAddress(handle, (void*) IMAGE_ORDINAL(*thunkRef)); //module->getProcAddress(handle, (LPCSTR)IMAGE_ORDINAL(*thunkRef), module->userdata);
					}
					else
					{
						var thunkData = (IMAGE_IMPORT_BY_NAME*)(codeBase + *thunkRef);
						*funcRef = (void*) GetProcAddress(handle, thunkData->Name); //module->getProcAddress(handle, (LPCSTR) & thunkData->Name, module->userdata);
					}
					if (*funcRef == (void*) 0)
					{
						result = false;
						break;
					}
				}

				if (!result)
				{
					FreeLibrary(handle);
					break;
				}
			}
			return true;
		}

		private unsafe bool FinalizeSections(MEMORYMODULE* module)
		{
			int i;
			var section = IMAGE_FIRST_SECTION(module->headers);
#if X64
			var imageOffset = (module->headers->OptionalHeader.ImageBase & 0xffffffff00000000);
#else
			var imageOffset = 0;
#endif
			SECTIONFINALIZEDATA sectionData;
			sectionData.address = (void*)(section->Misc.PhysicalAddress | imageOffset);
			sectionData.alignedAddress = ALIGN_DOWN(sectionData.address, module->pageSize);
			sectionData.size = GetRealSectionSize(module, section);
			sectionData.characteristics = section->Characteristics;
			sectionData.last = false;
			section++;

			// loop through all sections and change access flags
			for (i = 1; i < module->headers->FileHeader.NumberOfSections; i++, section++)
			{
				var sectionAddress = (void*)(section->Misc.PhysicalAddress | imageOffset);
				var alignedAddress = ALIGN_DOWN(sectionAddress, module->pageSize);
				var sectionSize = GetRealSectionSize(module, section);
				// Combine access flags of all sections that share a page
				// TODO(fancycode): We currently share flags of a trailing large section
				//   with the page of a first small section. This should be optimized.
				if (sectionData.alignedAddress == alignedAddress || (ulong)sectionData.address + sectionData.size > (ulong)alignedAddress)
				{
					// Section shares page with previous
					if ((section->Characteristics & IMAGE_SCN_MEM_DISCARDABLE) == 0 || (sectionData.characteristics & IMAGE_SCN_MEM_DISCARDABLE) == 0)
					{
						sectionData.characteristics = (uint) ((sectionData.characteristics | section->Characteristics) & ~IMAGE_SCN_MEM_DISCARDABLE);
					}
					else
					{
						sectionData.characteristics |= section->Characteristics;
					}
					sectionData.size = (uint) ((ulong)sectionAddress + sectionSize - (ulong)sectionData.address);
					continue;
				}

				if (!FinalizeSection(module, &sectionData))
				{
					return false;
				}
				sectionData.address = sectionAddress;
				sectionData.alignedAddress = alignedAddress;
				sectionData.size = sectionSize;
				sectionData.characteristics = section->Characteristics;
			}
			sectionData.last = true;
			if (!FinalizeSection(module, &sectionData))
			{
				return false;
			}
			return true;
		}

		private unsafe bool FinalizeSection(MEMORYMODULE* module, SECTIONFINALIZEDATA* sectionData)
		{
			uint oldProtect;

			if (sectionData->size == 0)
			{
				return true;
			}

			if ((sectionData->characteristics & IMAGE_SCN_MEM_DISCARDABLE) != 0)
			{
				// section is not needed any more and can safely be freed
				if (sectionData->address == sectionData->alignedAddress && (sectionData->last || module->headers->OptionalHeader.SectionAlignment == module->pageSize || sectionData->size%module->pageSize == 0))
				{
					// Only allowed to decommit whole pages
					VirtualFree((IntPtr) sectionData->address, sectionData->size, MEM_DECOMMIT);
				}
				return true;
			}

			// determine protection flags based on characteristics
			var executable = (sectionData->characteristics & IMAGE_SCN_MEM_EXECUTE) != 0 ? 1 : 0;
			var readable = (sectionData->characteristics & IMAGE_SCN_MEM_READ) != 0 ? 1 : 0;
			var writeable = (sectionData->characteristics & IMAGE_SCN_MEM_WRITE) != 0 ? 1 : 0;
			var protect = ProtectionFlags[executable][readable][writeable];
			if ((sectionData->characteristics & IMAGE_SCN_MEM_NOT_CACHED) != 0)
			{
				protect |= PAGE_NOCACHE;
			}

			// change memory access flags
			return VirtualProtect((IntPtr) sectionData->address, sectionData->size, protect, out oldProtect);
		}

		private unsafe bool ExecuteTLS(MEMORYMODULE* module)
		{
			var codeBase = module->codeBase;

			var directory = GET_HEADER_DICTIONARY(module, IMAGE_DIRECTORY_ENTRY_TLS);
			if (directory->VirtualAddress == 0)
			{
				return true;
			}

			var tls = (IMAGE_TLS_DIRECTORY*) (codeBase + directory->VirtualAddress);
			var cbPtr = tls->AddressOfCallBacks;
			var callback = Marshal.GetDelegateForFunctionPointer<PIMAGE_TLS_CALLBACK>((IntPtr) cbPtr);
			while (callback != null)
			{
				callback((IntPtr) codeBase, DLL_PROCESS_ATTACH, IntPtr.Zero);
				cbPtr += (uint) sizeof(void*);
				callback = Marshal.GetDelegateForFunctionPointer<PIMAGE_TLS_CALLBACK>((IntPtr) cbPtr);
			}
			return true;
		}

		private static uint[][][] ProtectionFlags = {
			new[]
			{
				new[] {PAGE_NOACCESS, PAGE_WRITECOPY},
				new[] {PAGE_READONLY, PAGE_READWRITE},
			},
			new[]
			{
				new[] {PAGE_EXECUTE, PAGE_EXECUTE_WRITECOPY},
				new[] {PAGE_EXECUTE_READ, PAGE_EXECUTE_READWRITE},
			}
		};

		private unsafe uint GetRealSectionSize(MEMORYMODULE* module, IMAGE_SECTION_HEADER* section)
		{
			var size = section->SizeOfRawData;
			if (size == 0)
			{
				if ((section->Characteristics & IMAGE_SCN_CNT_INITIALIZED_DATA) != 0)
				{
					size = module->headers->OptionalHeader.SizeOfInitializedData;
				}
				else if ((section->Characteristics & IMAGE_SCN_CNT_UNINITIALIZED_DATA) != 0)
				{
					size = module->headers->OptionalHeader.SizeOfUninitializedData;
				}
			}
			return size;
		}

		private static ulong IMAGE_ORDINAL(ulong ordinal)
		{
			return ordinal & 0xffff;
		}

		private static bool IMAGE_SNAP_BY_ORDINAL(ulong ordinal)
		{
			return (ordinal & IMAGE_ORDINAL_FLAG) != 0;
		}

		private static unsafe IMAGE_DATA_DIRECTORY* GET_HEADER_DICTIONARY(MEMORYMODULE* module, int idx)
		{
			switch (idx)
			{
				case 0:
					return &module->headers->OptionalHeader.DataDirectory.D0;
				case 1:
					return &module->headers->OptionalHeader.DataDirectory.D1;
				case 2:
					return &module->headers->OptionalHeader.DataDirectory.D2;
				case 3:
					return &module->headers->OptionalHeader.DataDirectory.D3;
				case 4:
					return &module->headers->OptionalHeader.DataDirectory.D4;
				case 5:
					return &module->headers->OptionalHeader.DataDirectory.D5;
				case 6:
					return &module->headers->OptionalHeader.DataDirectory.D6;
				case 7:
					return &module->headers->OptionalHeader.DataDirectory.D7;
				case 8:
					return &module->headers->OptionalHeader.DataDirectory.D8;
				case 9:
					return &module->headers->OptionalHeader.DataDirectory.D9;
				case 10:
					return &module->headers->OptionalHeader.DataDirectory.D10;
				case 11:
					return &module->headers->OptionalHeader.DataDirectory.D11;
				case 12:
					return &module->headers->OptionalHeader.DataDirectory.D12;
				case 13:
					return &module->headers->OptionalHeader.DataDirectory.D13;
				case 14:
					return &module->headers->OptionalHeader.DataDirectory.D14;
				case 15:
					return &module->headers->OptionalHeader.DataDirectory.D15;
			}
			return (IMAGE_DATA_DIRECTORY*) 0;
//			return module->headers->OptionalHeader.DataDirectory[idx];
		}

		private static unsafe IMAGE_SECTION_HEADER* IMAGE_FIRST_SECTION(IMAGE_NT_HEADERS* ntheader)
		{
			return (IMAGE_SECTION_HEADER*) ((ulong) ntheader + (ulong) (Marshal.OffsetOf(typeof(IMAGE_NT_HEADERS), "OptionalHeader") + ntheader->FileHeader.SizeOfOptionalHeader));
		}

		private static uint ALIGN_VALUE_UP(uint value, uint alignment)
		{
			return (value + alignment - 1) & ~(alignment - 1);
		}

		private static unsafe void* ALIGN_DOWN(void* address, uint alignment)
		{
			return (void*) ((uint)address & ~(alignment - 1));
		}

		private static bool CheckSize(int size, int expected)
		{
			return size >= expected;
		}
	}
}