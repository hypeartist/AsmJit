﻿using System;
using AsmJitTest.TestCases;

namespace AsmJitTest
{
	class Program
	{
		static void Main(string[] a)
		{
			var tr = new TestCaseRunner(false);

			tr.Add(new JumpCross());
			tr.Add(new JumpUnreachable1());
			tr.Add(new JumpUnreachable2());
			tr.Add(new AllocBase());
			tr.Add(new AllocManual());
			tr.Add(new AllocUseMem());
			tr.Add(new AllocMany1());
			tr.Add(new AllocMany2());
			tr.Add(new AllocImul1());
			tr.Add(new AllocImul2());
			tr.Add(new AllocIdiv1());
			tr.Add(new AllocSetz());
			tr.Add(new AllocShlRor());
			tr.Add(new AllocGpLo());
			tr.Add(new AllocRepMovsb());
			tr.Add(new AllocIfElse1());
			tr.Add(new AllocIfElse2());
			tr.Add(new AllocIfElse3());
			tr.Add(new AllocIfElse4());
			tr.Add(new AllocInt8());
			tr.Add(new AllocArgsIntPtr());
			tr.Add(new AllocArgsFloat());
			tr.Add(new AllocArgsDouble());
			tr.Add(new AllocRetFloat());
			tr.Add(new AllocRetDouble());
			tr.Add(new AllocStack());
			tr.Add(new AllocMemcpy());
			tr.Add(new AllocBlend());
			tr.Add(new CallBase());
			tr.Add(new CallFast());
			tr.Add(new CallManyArgs());
			tr.Add(new CallDuplicateArgs());
			tr.Add(new CallImmArgs());
			tr.Add(new CallPtrArgs());
			tr.Add(new CallFloatAsXmmRet());
			tr.Add(new CallDoubleAsXmmRet());
			tr.Add(new CallConditional());
			tr.Add(new CallMultiple());
			tr.Add(new CallRecursive());
			tr.Add(new CallMisc1());
			tr.Add(new CallMisc2());
			tr.Add(new CallMisc3());
			tr.Add(new CallMisc4());
			tr.Add(new MiscConstPool());
			tr.Add(new MiscMultiRet());

			foreach (var data in tr.Run())
			{
				var res = data.Item1;
				Console.WriteLine(res);
//				var disasm = data.Item2;
			}
			Console.ReadKey();
		}
	}
}
