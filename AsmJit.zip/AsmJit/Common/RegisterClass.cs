﻿namespace AsmJit.Common
{
	internal enum RegisterClass
	{
		Gp = 0,
		Mm = 1,
		K = 2,
		Xyz = 3,
		Fp = 4
	}
}