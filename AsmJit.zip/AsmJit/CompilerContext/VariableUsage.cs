namespace AsmJit.CompilerContext
{
	internal enum VariableUsage
	{
		None = 0,
		Reg = 1,
		Mem = 2
	}
}