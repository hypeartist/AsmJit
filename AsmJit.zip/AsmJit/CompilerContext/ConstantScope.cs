namespace AsmJit.CompilerContext
{
	public enum ConstantScope
	{
		Local = 0,
		Global = 1
	}
}