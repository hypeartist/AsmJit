﻿namespace AsmJit.CompilerContext
{
	public enum AligningMode
	{
		Code = 0,
		Data = 1,
		Zero = 2
	}
}