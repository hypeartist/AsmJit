using System;
using System.Collections.Generic;
using System.Linq;
using AsmJit.AssemblerContext;
using AsmJit.Common;
using AsmJit.Common.Operands;
using AsmJit.CompilerContext.CodeTree;
using CallingConvention = AsmJit.Common.CallingConvention;

namespace AsmJit.CompilerContext
{
	public sealed class Compiler : IDisposable
	{
		internal static readonly HashSet<Type> Actions = new HashSet<Type>
		{
			typeof(Action<>), 
			typeof(Action<,>),
			typeof(Action<,,>),
			typeof(Action<,,,>),
			typeof(Action<,,,,>),
			typeof(Action<,,,,,>),
			typeof(Action<,,,,,,>),
			typeof(Action<,,,,,,,>),
			typeof(Action<,,,,,,,,>),
			typeof(Action<,,,,,,,,,>),
			typeof(Action<,,,,,,,,,,>),
			typeof(Action<,,,,,,,,,,,>),
			typeof(Action<,,,,,,,,,,,,>),
			typeof(Action<,,,,,,,,,,,,,>),
			typeof(Action<,,,,,,,,,,,,,,>),
			typeof(Action<,,,,,,,,,,,,,,,>)
		};

		internal static readonly HashSet<Type> Funcs = new HashSet<Type>
		{
			typeof(Func<>), 
			typeof(Func<,>),
			typeof(Func<,,>),
			typeof(Func<,,,>),
			typeof(Func<,,,,>),
			typeof(Func<,,,,,>),
			typeof(Func<,,,,,,>),
			typeof(Func<,,,,,,,>),
			typeof(Func<,,,,,,,,>),
			typeof(Func<,,,,,,,,,>),
			typeof(Func<,,,,,,,,,,>),
			typeof(Func<,,,,,,,,,,,>),
			typeof(Func<,,,,,,,,,,,,>),
			typeof(Func<,,,,,,,,,,,,,>),
			typeof(Func<,,,,,,,,,,,,,,>),
			typeof(Func<,,,,,,,,,,,,,,,>),
			typeof(Func<,,,,,,,,,,,,,,,,>)
		};

		private List<VariableData> _variables = new List<VariableData>();
		private ConstantPool _localConstPool = new ConstantPool();
		private ConstantPool _globalConstPool = new ConstantPool();
		private Label _localConstPoolLabel;
		private Label _globalConstPoolLabel;		
		private CodeNode _firstNode;
		private CodeNode _lastNode;
		private CodeNode _currentNode;
		private FunctionNode _function;
		private CodeProcessor _codeProcessor;
		private Assembler _assembler;
		private CodeContext _codeContext;
		private List<Pointer> _data = new List<Pointer>();
		private Action<DataContext> _dataBlock;

		private Compiler()
		{
			_assembler = new Assembler();	
		}

		public static CodeContext<T> CreateContext<T>(CallingConvention convention = CallingConvention.HostDefault)
		{
			var t = typeof(T);

			var args = new Type[0];
			Type ret = null;
			Type delType;
			if (t == typeof(Action))
			{
				delType = DelegateCreator.NewDelegateType(args);
			}
			else if (Actions.Contains(t.GetGenericTypeDefinition()))
			{
				var gargs = t.GetGenericArguments();
				args = new Type[gargs.Length].InitializeWith(i => gargs[i]);
				delType = DelegateCreator.NewDelegateType(args);
			}
			else if (Funcs.Contains(t.GetGenericTypeDefinition()))
			{
				var gargs = t.GetGenericArguments();
				args = new Type[gargs.Length - 1].InitializeWith(i => gargs[i]);
				ret = gargs.Last();
				delType = DelegateCreator.NewDelegateType(ret, args);
			}
			else
			{
				throw new ArgumentException();
			}

			var compiler = new Compiler();
			var ctx = new CodeContext<T>(compiler, delType);
			compiler._codeContext = ctx;
			compiler._codeProcessor = new CodeProcessor(compiler._assembler, compiler, compiler._codeContext);

			compiler.BeginFunction(args.Select(a => a.GetVariableType()).ToArray(), ret.GetVariableType(), convention);
			return ctx;
		}

		internal void CreateReturn(Operand o0, Operand o1)
		{
			var node = new ReturnNode(o0, o1);
			AddNode(node);
		}
		
		internal void SetArgument(int i, Variable v)
		{
			if (!v.Id.IsVariableId())
			{
				throw new ArgumentException();
			}

			var vd = GetVariableData(v.Id);
			_function.SetArgument(i, vd);
		}

		internal Label GetEntryLabel()
		{
			return new Label(_function.Entry.LabelId);
		}

		internal Label GetExitLabel()
		{
			return new Label(_function.Exit.LabelId);
		}

		internal void Unfollow()
		{
			_assembler.Unfollow();
		}

		internal void Data(Action<DataContext> dataBlock)
		{
			_dataBlock = dataBlock;
		}

		internal void Embed(Pointer data, int size)
		{
			var node = CreateDataNode(data, size);
			AddNode(node);
		}

		internal void Bind(Label label)
		{
			var node = _assembler.GetLabelData(label.Id).ContextData;
			if (node == null)
			{
				throw new ArgumentException();
			}
			AddNode(node);
		}

		internal void Spill(Variable variable)
		{
			if (variable.Id == Constants.InvalidId) return;
			var node = CreateHintNode(variable, VariableHint.Spill, Constants.InvalidValue);
			AddNode(node);
		}

		internal void Allocate(Variable variable)
		{
			if (variable.Id == Constants.InvalidId) return;
			var node = CreateHintNode(variable, VariableHint.Alloc, Constants.InvalidValue);
			AddNode(node);
		}

		internal void Allocate(Variable variable, Register r)
		{
			if (variable.Id == Constants.InvalidId) return;
			var node = CreateHintNode(variable, VariableHint.Alloc, r.Index);
			AddNode(node);
		}

		internal void Unuse(Variable variable)
		{
			if (variable.Id == Constants.InvalidId) return;
			var node = CreateHintNode(variable, VariableHint.Unuse, Constants.InvalidValue);
			AddNode(node);
		}

		internal StackMemory CreateStack(int size, int alignment, string name = null)
		{
			if (size == 0)
			{
				throw new ArgumentException("Invalid alignment");
			}
			alignment = Math.Min(alignment, 64);
			var vd = CreateVariableData(VariableType.Stack, new VariableInfo(RegisterType.Invalid, size, 0, 0, name), name, alignment);
			return new StackMemory(MemoryType.StackIndex, vd.Id);
		}

		internal Memory CreateConstant(ConstantScope scope, Pointer data, int size)
		{
			var offset = 0;
			Label dstLabel;
			ConstantPool dstPool;
			switch (scope)
			{
				case ConstantScope.Local:
					if (_localConstPoolLabel == null || _localConstPoolLabel.Id == Constants.InvalidId)
					{
						_localConstPoolLabel = CreateLabel();
					}
					dstLabel = _localConstPoolLabel;
					dstPool = _localConstPool;
					break;
				case ConstantScope.Global:
					if (_globalConstPoolLabel == null || _globalConstPoolLabel.Id == Constants.InvalidId)
					{
						_globalConstPoolLabel = CreateLabel();
					}
					dstLabel = _globalConstPoolLabel;
					dstPool = _globalConstPool;
					break;
				default:
					throw new ArgumentOutOfRangeException("scope", scope, null);
			}
			dstPool.Add(data, size, ref offset);
			return Memory.Ptr(dstLabel, offset, size);
		}

		internal CallNode CreateCall(Operand op)
		{
			var node = new CallNode(op, _function.FunctionDeclaration);
			AddNode(node);
			return node;
		}

		internal CallNode CreateCall(Operand op, FunctionDeclaration fn)
		{
			var node = new CallNode(op, fn);
			AddNode(node);
			return node;
		}

		internal VariableData CreateVariableData(VariableType type, VariableInfo info, string name, int alignment = 0)
		{
			var varData = new VariableData(type, info, _variables.Count.AsVariableId(), name, alignment);
			_variables.Add(varData);
			return varData;
		}

		private void EmbedConstantPool(Label label, ConstantPool pool)
		{
			if (label.Id == Constants.InvalidId)
			{
				throw new ArgumentException("Invalid variable id");
			}

			Align(AligningMode.Data, pool.Alignment);
			Bind(label);

			var embedNode = CreateDataNode(Pointer.Invalid, pool.Size);

			pool.Fill(embedNode.Data);
			AddNode(embedNode);
		}

		internal void BeginFunction(VariableType[] args, VariableType ret, CallingConvention callingConvention)
		{
			_function = new FunctionNode(CreateLabelNode(), CreateLabelNode(), args, ret, callingConvention);

			AddNode(_function);
			AddNode(_function.Entry);
			var node = _currentNode;
			AddNode(_function.Exit); // Add function exit / epilog marker.
			AddNode(_function.End); // Add function end.
			SetCurrentNode(node);
		}

		internal Pointer EndFunction()
		{
			// Add local constant pool at the end of the function (if exist).
			SetCurrentNode(_function.Exit);

			_function.FunctionFlags |= FunctionNodeFlags.IsFinished;
			var func = _function;
			_function = null;

			SetCurrentNode(func.End);
			if (_dataBlock != null)
			{
				_dataBlock(new DataContext(this));
			}
			Finish();
			return Make();
		}

		internal Pointer EndFunction(out int codeSize)
		{
			// Add local constant pool at the end of the function (if exist).
			SetCurrentNode(_function.Exit);

			_function.FunctionFlags |= FunctionNodeFlags.IsFinished;
			var func = _function;
			_function = null;

			SetCurrentNode(func.End);
			if (_dataBlock != null)
			{
				_dataBlock(new DataContext(this));
			}

			Finish();
			return Make(out codeSize);
		}

		internal CodeNode SetCurrentNode(CodeNode node)
		{
			var old = _currentNode;
			_currentNode = node;
			return old;
		}

		internal CodeNode GetCurrentNode()
		{
			return _currentNode;
		}

		internal VariableData GetVariableData(int id)
		{
			id = id.GetActualVariableId();
			if (id == Constants.InvalidId || id >= _variables.Count)
			{
				throw new ArgumentException("Invalid id");
			}
			return _variables[id];
		}

		internal void Align(AligningMode mode, int offset)
		{
			var node = new AlignNode(mode, offset);
			AddNode(node);
		}

		internal CodeNode AddNode(CodeNode node)
		{
			if (node == null)
			{
				throw new ArgumentException();
			}
			if (node.Previous != null || node.Next != null)
			{
				throw new ArgumentException("Node already inserted");
			}

			if (_currentNode == null)
			{
				if (_firstNode == null)
				{
					_firstNode = node;
					_lastNode = node;
				}
				else
				{
					node.Next = _firstNode;
					_firstNode.Previous = node;
					_firstNode = node;
				}
			}
			else
			{
				var prev = _currentNode;
				var next = _currentNode.Next;

				node.Previous = prev;
				node.Next = next;

				prev.Next = node;
				if (next != null)
				{
					next.Previous = node;
				}
				else
				{
					_lastNode = node;
				}
			}
			return _currentNode = node;
		}

		internal CodeNode AddNodeBefore(CodeNode node, CodeNode @ref)
		{
			if (node == null || @ref == null)
			{
				throw new ArgumentException();
			}
			if (node.Previous != null || node.Next != null)
			{
				throw new ArgumentException("Node already inserted");
			}

			var prev = @ref.Previous;
			var next = @ref;

			node.Previous = prev;
			node.Next = next;

			next.Previous = node;
			if (prev != null)
			{
				prev.Next = node;
			}
			else
			{
				_firstNode = node;
			}

			return node;
		}

		internal void RemoveNode(CodeNode node)
		{
			var prev = node.Previous;
			var next = node.Next;

			if (_firstNode == node)
			{
				_firstNode = next;
			}
			else
			{
				prev.Next = next;
			}

			if (_lastNode == node)
			{
				_lastNode = prev;
			}
			else
			{
				next.Previous = prev;
			}

			node.Previous = null;
			node.Next = null;

			if (_currentNode == node)
			{
				_currentNode = prev;
			}
			AfterRemoveNode(node);
		}

		private void AfterRemoveNode(CodeNode node)
		{
			if (!node.Flags.IsSet(CodeNodeFlags.Jmp | CodeNodeFlags.Jcc)) return;

			var jj = new ValueSet<CodeNode, JumpNode>();

			var jump = node.As<JumpNode>();
			var label = jump.Target;

			if (label == null) return;
			// Disconnect.
			jj.Value0 = label;
			jj.Value1 = label.From;
			for (; ; )
			{
				var current = jj;
				if (current.Value1 == null) break;

				if (current.Value1 == jump)
				{
					jj.Value0 = jump;
					jj.Value1 = jump.NextJump;
					break;
				}

				jj.Value1 = current.Value1;
			}
			if (jj.Value0.Type == CodeNodeType.Label)
			{
				jj.Value0.As<LabelNode>().From = jj.Value1;
			}
			else
			{
				jj.Value0.As<JumpNode>().NextJump = jj.Value1;
			}
			label.ReferenceCount--;
		}

		internal Label CreateLabel()
		{
			return new Label(CreateLabelNode().LabelId);
		}

		private HintNode CreateHintNode(Variable var, VariableHint hint, int value)
		{
			var varData = GetVariableData(var.Id);
			var node = new HintNode(varData, hint, value);
			return node;
		}

		internal LabelNode CreateLabelNode()
		{
			int labelId;
			var data = _assembler.CreateLabelData(out labelId);
			var node = new LabelNode(labelId);
			data.ContextData = node;
			return node;
		}		

		private DataNode CreateDataNode(Pointer data, int size)
		{
			var clonedData = UnsafeMemory.Allocate(size);
			if (clonedData == Pointer.Invalid)
			{
				return null;
			}
			_data.Add(clonedData);
			if (data != Pointer.Invalid)
			{
				UnsafeMemory.Copy(clonedData, data, size);
			}

			return new DataNode(clonedData, size);
		}

		private void Finish()
		{
			if (_localConstPoolLabel != null && _localConstPoolLabel.Id != Constants.InvalidId)
			{
				EmbedConstantPool(_localConstPoolLabel, _localConstPool);
				_localConstPoolLabel.Reset();
				_localConstPool.Reset();
			}
			var node = _firstNode;
			do
			{
				var start = node;

				if (node.Type == CodeNodeType.Function)
				{
					var func = start.As<FunctionNode>();
					node = func.End;
					_codeProcessor.FetchAndTranslate(func);
				}

				do
				{
					node = node.Next;
				} while (node != null && node.Type != CodeNodeType.Function);

				_codeProcessor.Serialize(start, node);
				//				Cleanup();
			} while (node != null);			
		}

		private Pointer Make()
		{
			return _assembler.Make();
		}

		private Pointer Make(out int codeSize)
		{
			return _assembler.Make(out codeSize);
		}

		private void CreateInstructionNode(InstructionId instructionId, Operand[] operands)
		{
			var options = _assembler.GetInstructionOptionsAndReset();
			if (instructionId.IsJump())
			{
				LabelNode target = null;
				JumpNode next = null;
				CodeNodeFlags flags = 0;
				if (!options.IsSet(InstructionOptions.Unfollow))
				{
					if (operands[0].IsLabel())
					{
						target = _assembler.GetLabelData(operands[0].Id).ContextData;
					}
					else
					{
						options |= InstructionOptions.Unfollow;
					}
				}
				flags |= instructionId == InstructionId.Jmp ? CodeNodeFlags.Jmp | CodeNodeFlags.Taken : CodeNodeFlags.Jcc;

				if (target != null)
				{
					next = target.From;
				}

				// The 'jmp' is always taken, conditional jump can contain hint, we detect it.
				if (instructionId == InstructionId.Jmp)
				{
					flags |= CodeNodeFlags.Taken;
				}
				else if (options.IsSet(InstructionOptions.Taken))
				{
					flags |= CodeNodeFlags.Taken;
				}

				var node = new JumpNode(instructionId, options, operands);
				node.Flags |= flags;
				node.Target = target;
				if (target != null)
				{
					node.NextJump = next;
					target.From = node;
					target.ReferenceCount++;
				}
				AddNode(node);
				return;
			}
			var inst = new InstructionNode(instructionId, options, operands);
			AddNode(inst);
		}

		internal TV CreateVariable<TV>(VariableType type, string name = null) where TV : Variable
		{
			type = type.GetMappedType();
			if (type.IsInvalid())
			{
				throw new ArgumentException();
			}
			var varInfo = type.GetVariableInfo();
			VariableData varData;
			Variable var;
			switch (type)
			{
				case VariableType.Int8:
				case VariableType.UInt8:
				case VariableType.Int16:
				case VariableType.UInt16:
				case VariableType.Int32:
				case VariableType.UInt32:
				case VariableType.Int64:
				case VariableType.UInt64:
				case VariableType.IntPtr:
				case VariableType.UIntPtr:
					if (typeof(TV) != typeof(GpVariable))
					{
						throw new ArgumentException();
					}
					varData = CreateVariableData(type, varInfo, name);
					var = new GpVariable((GpVariableType) type, varData.Id);
					break;
				case VariableType.Fp32:
				case VariableType.Fp64:
					if (typeof(TV) != typeof(FpVariable))
					{
						throw new ArgumentException();
					}
					varData = CreateVariableData(type, varInfo, name);
					var = new FpVariable((FpVariableType) type, varData.Id);
					break;
				case VariableType.Xmm:
				case VariableType.XmmSs:
				case VariableType.XmmSd:
					if (typeof(TV) != typeof(XmmVariable))
					{
						throw new ArgumentException();
					}
					varData = CreateVariableData(type, varInfo, name);
					var = new XmmVariable((XmmVariableType) type, varData.Id);
					break;
				default:
					throw new ArgumentException();
			}
			return (TV)var;
		}

		internal void Emit(InstructionId instructionId)
		{
			CreateInstructionNode(instructionId, new Operand[0]);
		}

		internal void Emit(InstructionId instructionId, long o0)
		{
			CreateInstructionNode(instructionId, new Operand[] { new Immediate(o0) });
		}

		internal void Emit(InstructionId instructionId, ulong o0)
		{
			CreateInstructionNode(instructionId, new Operand[] { new Immediate(o0) });
		}

		internal void Emit(InstructionId instructionId, Operand o0)
		{
			CreateInstructionNode(instructionId, new[] { o0 });
		}

		internal void Emit(InstructionId instructionId, Operand o0, long o1)
		{
			CreateInstructionNode(instructionId, new[] { o0, new Immediate(o1) });
		}

		internal void Emit(InstructionId instructionId, Operand o0, ulong o1)
		{
			CreateInstructionNode(instructionId, new[] { o0, new Immediate(o1) });
		}

		internal void Emit(InstructionId instructionId, Operand o0, Operand o1)
		{
			CreateInstructionNode(instructionId, new[] { o0, o1 });
		}

		internal void Emit(InstructionId instructionId, Operand o0, Operand o1, Operand o2)
		{
			CreateInstructionNode(instructionId, new[] { o0, o1, o2 });
		}

		internal void Emit(InstructionId instructionId, Operand o0, Operand o1, long o2)
		{
			CreateInstructionNode(instructionId, new[] { o0, o1, new Immediate(o2), });
		}

		internal void Emit(InstructionId instructionId, Operand o0, Operand o1, ulong o2)
		{
			CreateInstructionNode(instructionId, new[] { o0, o1, new Immediate(o2), });
		}

		internal void Emit(InstructionId instructionId, Operand o0, Operand o1, Operand o2, Operand o3)
		{
			CreateInstructionNode(instructionId, new[] { o0, o1, o2, o3 });
		}

		internal void Emit(InstructionId instructionId, Operand o0, Operand o1, Operand o2, long o3)
		{
			CreateInstructionNode(instructionId, new[] { o0, o1, o2, new Immediate(o3), });
		}

		internal void Emit(InstructionId instructionId, Operand o0, Operand o1, Operand o2, ulong o3)
		{
			CreateInstructionNode(instructionId, new[] { o0, o1, o2, new Immediate(o3), });
		}

		internal void Emit(InstructionId instructionId, Operand o0, Operand o1, Operand o2, Operand o3, Operand o4)
		{
			CreateInstructionNode(instructionId, new[] { o0, o1, o2, o3, o4 });
		}

		internal static GpRegister GpbLo(int index)
		{
			return new GpRegister(GpRegisterType.GpbLo, index);
		}

		internal static GpRegister GpbHi(int index)
		{
			return new GpRegister(GpRegisterType.GpbHi, index);
		}

		internal static GpRegister Gpw(int index)
		{
			return new GpRegister(GpRegisterType.Gpw, index);
		}

		internal static GpRegister Gpd(int index)
		{
			return new GpRegister(GpRegisterType.Gpd, index);
		}

		internal static GpRegister Gpq(int index)
		{
			return new GpRegister(GpRegisterType.Gpq, index);
		}

		internal static FpRegister Fp(int index)
		{
			return new FpRegister(index);
		}

		internal static MmRegister Mm(int index)
		{
			return new MmRegister(index);
		}

		internal static KRegister K(int index)
		{
			return new KRegister(index);
		}

		internal static XmmRegister Xmm(int index)
		{
			return new XmmRegister(index);
		}

		internal static YmmRegister Ymm(int index)
		{
			return new YmmRegister(index);
		}

		internal static ZmmRegister Zmm(int index)
		{
			return new ZmmRegister(index);
		}
//
//		public Action CreateAction(Action<CodeContext> f, CallingConvention callingConvention = CallingConvention.HostDefault)
//		{
//			BeginFunction(new VariableType[0], VariableType.Invalid, callingConvention);
//			f(_codeContext);
//			var fp = EndFunction();
//			var fn = Marshal.GetDelegateForFunctionPointer<Action>(fp);
//			return fn;
//		}
//
//		public Func<TR> CreateFunction<TR>(Action<CodeContext> f, CallingConvention callingConvention = CallingConvention.HostDefault)
//		{
//			BeginFunction(new VariableType[0], typeof(TR).GetVariableType(), callingConvention);
//			f(_codeContext);
//			var fp = EndFunction();
//			return fp.ToCallable<Func<TR>>(DelegateCreator.NewDelegateType(typeof(TR)));
//		}
//
//		public Action<TA0> CreateAction<TA0>(Action<CodeContext> f, CallingConvention callingConvention = CallingConvention.HostDefault)
//		{
//			BeginFunction(new[] { typeof(TA0).GetVariableType() }, VariableType.Invalid, callingConvention);
//			f(_codeContext);
//			var fp = EndFunction();
//			return fp.ToCallable<Action<TA0>>(DelegateCreator.NewDelegateType(new[] { typeof(TA0) }));
//		}
//
//		public Func<TA0, TR> CreateFunction<TA0, TR>(Action<CodeContext> f, CallingConvention callingConvention = CallingConvention.HostDefault)
//		{
//			BeginFunction(new[] { typeof(TA0).GetVariableType() }, typeof(TR).GetVariableType(), callingConvention);
//			f(_codeContext);
//			var fp = EndFunction();
//			return fp.ToCallable<Func<TA0, TR>>(DelegateCreator.NewDelegateType(typeof(TR), new[] { typeof(TA0) }));
//		}
//
//		public Action<TA0, TA1> CreateAction<TA0, TA1>(Action<CodeContext> f, CallingConvention callingConvention = CallingConvention.HostDefault)
//		{
//			BeginFunction(new[] { typeof(TA0).GetVariableType(), typeof(TA1).GetVariableType() }, VariableType.Invalid, callingConvention);
//			f(_codeContext);
//			var fp = EndFunction();
//			return fp.ToCallable<Action<TA0, TA1>>(DelegateCreator.NewDelegateType(new[] { typeof(TA0), typeof(TA1) }));
//		}
//
//		public Func<TA0, TA1, TR> CreateFunction<TA0, TA1, TR>(Action<CodeContext> f, CallingConvention callingConvention = CallingConvention.HostDefault)
//		{
//			BeginFunction(new[] { typeof(TA0).GetVariableType(), typeof(TA1).GetVariableType() }, typeof(TR).GetVariableType(), callingConvention);
//			f(_codeContext);
//			var fp = EndFunction();
//			return fp.ToCallable<Func<TA0, TA1, TR>>(DelegateCreator.NewDelegateType(typeof(TR), new[] { typeof(TA0), typeof(TA1) }));
//		}
//
//		public Action<TA0, TA1, TA2> CreateAction<TA0, TA1, TA2>(Action<CodeContext> f, CallingConvention callingConvention = CallingConvention.HostDefault)
//		{
//			BeginFunction(new[] { typeof(TA0).GetVariableType(), typeof(TA1).GetVariableType(), typeof(TA2).GetVariableType() }, VariableType.Invalid, callingConvention);
//			f(_codeContext);
//			var fp = EndFunction();
//			return fp.ToCallable<Action<TA0, TA1, TA2>>(DelegateCreator.NewDelegateType(new[] { typeof(TA0), typeof(TA1), typeof(TA2) }));
//		}
//
//		public Func<TA0, TA1, TA2, TR> CreateFunction<TA0, TA1, TA2, TR>(Action<CodeContext> f, CallingConvention callingConvention = CallingConvention.HostDefault)
//		{
//			BeginFunction(new[] { typeof(TA0).GetVariableType(), typeof(TA1).GetVariableType(), typeof(TA2).GetVariableType() }, typeof(TR).GetVariableType(), callingConvention);
//			f(_codeContext);
//			var fp = EndFunction();
//			return fp.ToCallable<Func<TA0, TA1, TA2, TR>>(DelegateCreator.NewDelegateType(typeof(TR), new[] { typeof(TA0), typeof(TA1), typeof(TA2) }));
//		}
//
//		public Action<TA0, TA1, TA2, TA3> CreateAction<TA0, TA1, TA2, TA3>(Action<CodeContext> f, CallingConvention callingConvention = CallingConvention.HostDefault)
//		{
//			BeginFunction(new[] { typeof(TA0).GetVariableType(), typeof(TA1).GetVariableType(), typeof(TA2).GetVariableType(), typeof(TA3).GetVariableType() }, VariableType.Invalid, callingConvention);
//			f(_codeContext);
//			var fp = EndFunction();
//			return fp.ToCallable<Action<TA0, TA1, TA2, TA3>>(DelegateCreator.NewDelegateType(new[] { typeof(TA0), typeof(TA1), typeof(TA2), typeof(TA3) }));
//		}
//
//		public Func<TA0, TA1, TA2, TA3, TR> CreateFunction<TA0, TA1, TA2, TA3, TR>(Action<CodeContext> f, CallingConvention callingConvention = CallingConvention.HostDefault)
//		{
//			BeginFunction(new[] { typeof(TA0).GetVariableType(), typeof(TA1).GetVariableType(), typeof(TA2).GetVariableType(), typeof(TA3).GetVariableType() }, typeof(TR).GetVariableType(), callingConvention);
//			f(_codeContext);
//			var fp = EndFunction();
//			return fp.ToCallable<Func<TA0, TA1, TA2, TA3, TR>>(DelegateCreator.NewDelegateType(typeof(TR), new[] { typeof(TA0), typeof(TA1), typeof(TA2), typeof(TA3) }));
//		}
//
//		public Action<TA0, TA1, TA2, TA3, TA4> CreateAction<TA0, TA1, TA2, TA3, TA4>(Action<CodeContext> f, CallingConvention callingConvention = CallingConvention.HostDefault)
//		{
//			BeginFunction(new[] { typeof(TA0).GetVariableType(), typeof(TA1).GetVariableType(), typeof(TA2).GetVariableType(), typeof(TA3).GetVariableType(), typeof(TA4).GetVariableType() }, VariableType.Invalid, callingConvention);
//			f(_codeContext);
//			var fp = EndFunction();
//			return fp.ToCallable<Action<TA0, TA1, TA2, TA3, TA4>>(DelegateCreator.NewDelegateType(new[] { typeof(TA0), typeof(TA1), typeof(TA2), typeof(TA3), typeof(TA4) }));
//		}
//
//		public Func<TA0, TA1, TA2, TA3, TA4, TR> CreateFunction<TA0, TA1, TA2, TA3, TA4, TR>(Action<CodeContext> f, CallingConvention callingConvention = CallingConvention.HostDefault)
//		{
//			BeginFunction(new[] { typeof(TA0).GetVariableType(), typeof(TA1).GetVariableType(), typeof(TA2).GetVariableType(), typeof(TA3).GetVariableType(), typeof(TA4).GetVariableType() }, typeof(TR).GetVariableType(), callingConvention);
//			f(_codeContext);
//			var fp = EndFunction();
//			return fp.ToCallable<Func<TA0, TA1, TA2, TA3, TA4, TR>>(DelegateCreator.NewDelegateType(typeof(TR), new[] { typeof(TA0), typeof(TA1), typeof(TA2), typeof(TA3), typeof(TA4) }));
//		}
//
//		public Action<TA0, TA1, TA2, TA3, TA4, TA5> CreateAction<TA0, TA1, TA2, TA3, TA4, TA5>(Action<CodeContext> f, CallingConvention callingConvention = CallingConvention.HostDefault)
//		{
//			BeginFunction(new[] { typeof(TA0).GetVariableType(), typeof(TA1).GetVariableType(), typeof(TA2).GetVariableType(), typeof(TA3).GetVariableType(), typeof(TA4).GetVariableType(), typeof(TA5).GetVariableType() }, VariableType.Invalid, callingConvention);
//			f(_codeContext);
//			var fp = EndFunction();
//			return fp.ToCallable<Action<TA0, TA1, TA2, TA3, TA4, TA5>>(DelegateCreator.NewDelegateType(new[] { typeof(TA0), typeof(TA1), typeof(TA2), typeof(TA3), typeof(TA4), typeof(TA5) }));
//		}
//
//		public Func<TA0, TA1, TA2, TA3, TA4, TA5, TR> CreateFunction<TA0, TA1, TA2, TA3, TA4, TA5, TR>(Action<CodeContext> f, CallingConvention callingConvention = CallingConvention.HostDefault)
//		{
//			BeginFunction(new[] { typeof(TA0).GetVariableType(), typeof(TA1).GetVariableType(), typeof(TA2).GetVariableType(), typeof(TA3).GetVariableType(), typeof(TA4).GetVariableType(), typeof(TA5).GetVariableType() }, typeof(TR).GetVariableType(), callingConvention);
//			f(_codeContext);
//			var fp = EndFunction();
//			return fp.ToCallable<Func<TA0, TA1, TA2, TA3, TA4, TA5, TR>>(DelegateCreator.NewDelegateType(typeof(TR), new[] { typeof(TA0), typeof(TA1), typeof(TA2), typeof(TA3), typeof(TA4), typeof(TA5) }));
//		}
//
//		public Action<TA0, TA1, TA2, TA3, TA4, TA5, TA6> CreateAction<TA0, TA1, TA2, TA3, TA4, TA5, TA6>(Action<CodeContext> f, CallingConvention callingConvention = CallingConvention.HostDefault)
//		{
//			BeginFunction(new[] { typeof(TA0).GetVariableType(), typeof(TA1).GetVariableType(), typeof(TA2).GetVariableType(), typeof(TA3).GetVariableType(), typeof(TA4).GetVariableType(), typeof(TA5).GetVariableType(), typeof(TA6).GetVariableType() }, VariableType.Invalid, callingConvention);
//			f(_codeContext);
//			var fp = EndFunction();
//			return fp.ToCallable<Action<TA0, TA1, TA2, TA3, TA4, TA5, TA6>>(DelegateCreator.NewDelegateType(new[] { typeof(TA0), typeof(TA1), typeof(TA2), typeof(TA3), typeof(TA4), typeof(TA5), typeof(TA6) }));
//		}
//
//		public Func<TA0, TA1, TA2, TA3, TA4, TA5, TA6, TR> CreateFunction<TA0, TA1, TA2, TA3, TA4, TA5, TA6, TR>(Action<CodeContext> f, CallingConvention callingConvention = CallingConvention.HostDefault)
//		{
//			BeginFunction(new[] { typeof(TA0).GetVariableType(), typeof(TA1).GetVariableType(), typeof(TA2).GetVariableType(), typeof(TA3).GetVariableType(), typeof(TA4).GetVariableType(), typeof(TA5).GetVariableType(), typeof(TA6).GetVariableType() }, typeof(TR).GetVariableType(), callingConvention);
//			f(_codeContext);
//			var fp = EndFunction();
//			return fp.ToCallable<Func<TA0, TA1, TA2, TA3, TA4, TA5, TA6, TR>>(DelegateCreator.NewDelegateType(typeof(TR), new[] { typeof(TA0), typeof(TA1), typeof(TA2), typeof(TA3), typeof(TA4), typeof(TA5), typeof(TA6) }));
//		}
//
//		public Action<TA0, TA1, TA2, TA3, TA4, TA5, TA6, TA7> CreateAction<TA0, TA1, TA2, TA3, TA4, TA5, TA6, TA7>(Action<CodeContext> f, CallingConvention callingConvention = CallingConvention.HostDefault)
//		{
//			BeginFunction(new[] { typeof(TA0).GetVariableType(), typeof(TA1).GetVariableType(), typeof(TA2).GetVariableType(), typeof(TA3).GetVariableType(), typeof(TA4).GetVariableType(), typeof(TA5).GetVariableType(), typeof(TA6).GetVariableType(), typeof(TA7).GetVariableType() }, VariableType.Invalid, callingConvention);
//			f(_codeContext);
//			var fp = EndFunction();
//			return fp.ToCallable<Action<TA0, TA1, TA2, TA3, TA4, TA5, TA6, TA7>>(DelegateCreator.NewDelegateType(new[] { typeof(TA0), typeof(TA1), typeof(TA2), typeof(TA3), typeof(TA4), typeof(TA5), typeof(TA6), typeof(TA7) }));
//		}
//
//		public Func<TA0, TA1, TA2, TA3, TA4, TA5, TA6, TA7, TR> CreateFunction<TA0, TA1, TA2, TA3, TA4, TA5, TA6, TA7, TR>(Action<CodeContext> f, CallingConvention callingConvention = CallingConvention.HostDefault)
//		{
//			BeginFunction(new[] { typeof(TA0).GetVariableType(), typeof(TA1).GetVariableType(), typeof(TA2).GetVariableType(), typeof(TA3).GetVariableType(), typeof(TA4).GetVariableType(), typeof(TA5).GetVariableType(), typeof(TA6).GetVariableType(), typeof(TA7).GetVariableType() }, typeof(TR).GetVariableType(), callingConvention);
//			f(_codeContext);
//			var fp = EndFunction();
//			return fp.ToCallable<Func<TA0, TA1, TA2, TA3, TA4, TA5, TA6, TA7, TR>>(DelegateCreator.NewDelegateType(typeof(TR), new[] { typeof(TA0), typeof(TA1), typeof(TA2), typeof(TA3), typeof(TA4), typeof(TA5), typeof(TA6), typeof(TA7) }));
//		}
		public void Dispose()
		{
			foreach (var pointer in _data)
			{
				UnsafeMemory.Free(pointer);
			}
		}
	}
}